"""Playwright helpers shared by browser-based collectors.

Design rules:
* Login is always done **manually by the user** in a visible browser window
  (no CAPTCHA / 2FA bypassing, passwords are never stored by this tool).
* After login, the browser's storage state (cookies) is saved locally under
  ``data/profiles/<profile>/sessions/<source>.json`` with 0600 permissions.
* Collection runs headless re-using that saved session, and only *reads*.
* The login window uses a persistent browser profile (``data/profiles/<profile>/browser``)
  shared by all sites, so the identity provider (e.g. the Ministry of Education login)
  can remember the user like a normal browser does. When a site's own session expires,
  ``silent_refresh`` just reopens the site headless in that profile: if the identity
  provider still remembers the user, the site logs in by itself. Nothing is typed or
  clicked, and if the site asks for a password / code / bot check, the user logs in by hand.
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from ..config import Settings

CHROMIUM_DEPS_HINT = (
    "Chromium של Playwright חסר ספריות מערכת. הריצו פעם אחת:\n"
    "  sudo apt-get install -y libnss3 libnspr4\n"
    "(או: sudo ~/school-tools/.venv/bin/playwright install-deps chromium)"
)


def session_path(settings: Settings, source: str) -> Path:
    return settings.sessions_dir / f"{source}.json"


def has_session(settings: Settings, source: str) -> bool:
    return session_path(settings, source).is_file()


def browser_profile_dir(settings: Settings) -> Path:
    return settings.profile_dir / "browser"


def _deps_error(e: Exception) -> bool:
    msg = str(e)
    return "shared libraries" in msg or "libnss3" in msg or "Host system is missing" in msg


def _launch(p, headless: bool):
    try:
        return p.chromium.launch(headless=headless)
    except Exception as e:  # missing libnss3 etc.
        if _deps_error(e):
            raise RuntimeError(CHROMIUM_DEPS_HINT) from e
        raise


def _launch_persistent(p, settings: Settings, headless: bool):
    """A browser context backed by the on-disk profile (remembers SSO cookies)."""
    d = browser_profile_dir(settings)
    d.mkdir(parents=True, exist_ok=True)
    d.chmod(0o700)
    try:
        return p.chromium.launch_persistent_context(
            str(d), headless=headless, locale="he-IL", timezone_id=settings.timezone)
    except Exception as e:
        if _deps_error(e):
            raise RuntimeError(CHROMIUM_DEPS_HINT) from e
        raise


_MULTI_TLD = {"co", "org", "ac", "gov", "net", "muni", "k12"}


def site_domain_pattern(url: str) -> re.Pattern:
    """Regex matching cookie domains of the site itself (e.g. ``mashov.info``), not its SSO."""
    from urllib.parse import urlparse

    labels = (urlparse(url).hostname or "").split(".")
    n = 3 if len(labels) >= 3 and labels[-2] in _MULTI_TLD else 2
    base = ".".join(labels[-n:])
    return re.compile(r"(^|\.)" + re.escape(base) + r"$")


def silent_refresh(settings: Settings, source: str, start_url: str,
                   wait_ms: int = 8000) -> bool:
    """Reopen the site headless in the persistent profile and save its fresh session.

    Only navigates to the site's own address and waits; returns False when there is
    no profile yet. Whether the refreshed session works is decided by the collector.
    """
    from playwright.sync_api import sync_playwright

    if not browser_profile_dir(settings).is_dir() or not start_url:
        return False
    target = session_path(settings, source)
    with sync_playwright() as p:
        context = _launch_persistent(p, settings, headless=True)
        try:
            page = context.pages[0] if context.pages else context.new_page()
            try:
                page.goto(start_url, wait_until="domcontentloaded", timeout=30000)
                page.wait_for_load_state("networkidle", timeout=20000)
            except Exception:
                pass  # slow SSO redirects: keep whatever state was reached
            page.wait_for_timeout(wait_ms)
            context.storage_state(path=str(target))
            target.chmod(0o600)
        finally:
            context.close()
    return True


def _wait_for_user(context, target: Path, message: str,
                   on_tick: Callable[[], None] | None = None) -> str:
    """Wait until the user presses Enter in the terminal OR closes the browser window.

    The session is saved every few seconds while the window is open, so closing
    the window instead of pressing Enter does not lose the login.
    Returns "enter" or "closed".
    """
    import select
    import time

    print(message, end="", flush=True)
    last_save = 0.0
    while True:
        if on_tick:
            on_tick()
        open_pages = [pg for pg in context.pages if not pg.is_closed()]
        if not open_pages:
            print("\n   (חלון הדפדפן נסגר)")
            return "closed"
        if time.time() - last_save > 3:
            try:
                context.storage_state(path=str(target))
                target.chmod(0o600)
                last_save = time.time()
            except Exception:
                pass
        if sys.stdin.isatty():
            ready, _, _ = select.select([sys.stdin], [], [], 0)
            if ready:
                sys.stdin.readline()
                break
        try:
            # Short wait on the page also lets Playwright process browser events.
            open_pages[0].wait_for_timeout(400)
        except Exception:
            continue  # the window was closed during the wait
    try:
        context.storage_state(path=str(target))
        target.chmod(0o600)
    except Exception:
        pass
    return "enter"


def manual_login(settings: Settings, source: str, start_url: str,
                 display_name: str, prompt: Callable[[str], str] = input) -> Path:
    """Open a visible browser at ``start_url``; the user logs in; we save the session."""
    from playwright.sync_api import sync_playwright

    settings.ensure_dirs()
    target = session_path(settings, source)
    with sync_playwright() as p:
        context = _launch_persistent(p, settings, headless=False)
        # Fresh login for this site (a restored session can leave some sites
        # half-logged-in), but keep the identity provider's cookies in the profile.
        try:
            context.clear_cookies(domain=site_domain_pattern(start_url))
        except Exception:
            pass
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(start_url)
        print(f"\n🔐 נפתח חלון דפדפן של {display_name}.")
        print("   התחברו ידנית (כולל אימות דו-שלבי אם נדרש).")
        print("   אם יש אפשרות \"זכור אותי\" / \"הישאר מחובר\" — כדאי לסמן אותה.")
        _wait_for_user(context, target,
                       "   כשאתם רואים את המסך הראשי של האתר — חזרו לכאן והקישו Enter"
                       " (או סגרו את החלון)... ")
        try:
            context.close()
        except Exception:
            pass
    print(f"✅ ההתחברות נשמרה מקומית ({target.name}).")
    return target


def capture_session(settings: Settings, source: str, start_url: str, display_name: str,
                    prompt: Callable[[str], str] = input, fresh: bool = True,
                    capture_dom: bool = False) -> Path:
    """Calibration mode: user browses the relevant pages; we record the JSON the site loads.

    The capture is saved only locally (gitignored) and is used to build the
    parser from the site's *real* structure instead of guessing it.
    """
    from playwright.sync_api import sync_playwright

    settings.ensure_dirs()
    target = session_path(settings, source)
    out_dir = settings.captures_dir / source
    out_dir.mkdir(parents=True, exist_ok=True)
    out_dir.chmod(0o700)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_file = out_dir / f"capture-{stamp}.jsonl"
    counter = {"n": 0}
    fh = out_file.open("w", encoding="utf-8")
    out_file.chmod(0o600)

    pending: list[Any] = []

    def on_response(resp):
        # Event handlers must not call blocking Playwright APIs: just queue.
        try:
            ctype = resp.headers.get("content-type", "")
            # POST too: some sites (CET) load data via POST queries. Only responses are
            # recorded; the tool itself never sends anything during capture.
            if "json" in ctype and resp.request.method in ("GET", "POST"):
                pending.append(resp)
            elif ("html" in ctype and resp.request.method == "GET"
                  and resp.request.resource_type == "document" and resp.status == 200):
                # Server-rendered sites (e.g. ClassIt) put the data in the HTML itself.
                pending.append(resp)
            elif resp.status >= 400 and resp.request.resource_type in ("xhr", "fetch"):
                failures.append({"meta": "http_error", "url": resp.url, "type": "fetch",
                                 "error": f"HTTP {resp.status}"})
        except Exception:
            pass

    def on_failed(req):
        # Diagnostics only: which requests failed (URL path + error), no bodies.
        try:
            if req.resource_type in ("xhr", "fetch", "document"):
                failures.append({"meta": "failed", "url": req.url, "type": req.resource_type,
                                 "error": req.failure})
        except Exception:
            pass

    failures: list[dict[str, Any]] = []

    dom_state: dict[str, Any] = {"ctx": None, "last": 0.0, "seen": set()}

    def snapshot_dom():
        # Sites that render data client-side (e.g. ClassIt) never send it as JSON or as a
        # document: save the rendered page every few seconds, only when it changed.
        import hashlib
        import time
        ctx = dom_state["ctx"]
        if ctx is None or time.time() - dom_state["last"] < 3:
            return
        dom_state["last"] = time.time()
        for pg in list(ctx.pages):
            try:
                if pg.is_closed():
                    continue
                html = pg.content()
            except Exception:
                continue
            digest = hashlib.sha1(html.encode("utf-8", "ignore")).hexdigest()
            if digest in dom_state["seen"]:
                continue
            dom_state["seen"].add(digest)
            fh.write(json.dumps({"url": pg.url, "page": pg.url, "dom": html}, ensure_ascii=False) + "\n")
            fh.flush()
            counter["n"] += 1
            path = re.sub(r"https?://[^/]+", "", pg.url).split("?")[0]
            print(f"\n   📸 [{counter['n']}] {path} צילום עמוד ({len(html) // 1024}KB)", end="", flush=True)

    def drain():
        snapshot_dom()
        while failures:
            rec = failures.pop(0)
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fh.flush()
            path = re.sub(r"https?://[^/]+", "", rec["url"]).split("?")[0]
            print(f"\n   ⚠️  בקשה נכשלה: {path} ({rec['error']})", end="", flush=True)
        # Written immediately, so nothing is lost if the window is closed.
        while pending:
            resp = pending.pop(0)
            try:
                rec = {"url": resp.url, "status": resp.status, "page": resp.frame.url,
                       "method": resp.request.method}
                if "html" in resp.headers.get("content-type", ""):
                    rec["html"] = resp.text()
                else:
                    rec["body"] = resp.json()
            except Exception:
                continue
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fh.flush()
            counter["n"] += 1
            # Live feedback: endpoint path + item count only (no personal values).
            path = re.sub(r"https?://[^/]+", "", resp.url).split("?")[0]
            path = re.sub(r"[0-9a-fA-F-]{20,}", "…", path)
            body = rec.get("body")
            if "html" in rec:
                size = f"עמוד HTML ({len(rec['html']) // 1024}KB)"
            else:
                size = f"{len(body)} פריטים" if isinstance(body, (list, dict)) else ""
            print(f"\n   📥 [{counter['n']}] {path} {size}", end="", flush=True)

    with sync_playwright() as p:
        browser = _launch(p, headless=False)
        ctx_kw: dict[str, Any] = {"locale": "he-IL", "timezone_id": settings.timezone}
        # Fresh by default: some sites keep part of the login in per-tab memory that a saved
        # session cannot restore, so the user logs in and browses in the same window.
        if target.is_file() and not fresh:
            ctx_kw["storage_state"] = str(target)
        context = browser.new_context(**ctx_kw)
        context.on("response", on_response)
        context.on("requestfailed", on_failed)
        page = context.new_page()
        page.goto(start_url)
        if capture_dom:
            dom_state["ctx"] = context
        print(f"\n🧭 מצב כיול ל-{display_name}.")
        print("   קודם התחברו בחלון שנפתח (גם אם כבר התחברתם קודם).")
        print("   היכנסו בתפריט של האתר לכל עמוד רלוונטי (למשל: התנהגות, הודעות, ציונים,")
        print("   שיעורי בית / משימות), וחכו בכל עמוד כמה שניות. לא ללחוץ על 'שלח' או 'הגש'.")
        print("   על כל נתון שנקלט תופיע כאן שורה עם 📥 — כך רואים שזה עובד.")
        _wait_for_user(context, target, "   בסיום הקישו Enter כאן (או סגרו את החלון)... ",
                       on_tick=drain)
        drain()
        try:
            browser.close()
        except Exception:
            pass
    fh.close()
    print(f"✅ נשמרו {counter['n']} תגובות (JSON/HTML) מקומית: {out_file}")
    return out_file


class HeadlessSession:
    """Context manager: headless browser with the saved session + JSON response capture."""

    def __init__(self, settings: Settings, source: str):
        self.settings = settings
        self.source = source
        self.responses: list[dict[str, Any]] = []
        self._pending: list[Any] = []
        self._pw = None
        self.browser = None
        self.context = None
        self.page = None

    def __enter__(self) -> "HeadlessSession":
        from playwright.sync_api import sync_playwright

        self._pw = sync_playwright().start()
        self.browser = _launch(self._pw, headless=self.settings.headless)
        self.context = self.browser.new_context(
            storage_state=str(session_path(self.settings, self.source)),
            locale="he-IL", timezone_id=self.settings.timezone,
        )
        self.context.on("response", self._on_response)
        self.page = self.context.new_page()
        return self

    def _on_response(self, resp) -> None:
        try:
            if "json" in resp.headers.get("content-type", "") and resp.request.method == "GET":
                self._pending.append(resp)
        except Exception:
            pass

    def _drain(self) -> None:
        while self._pending:
            resp = self._pending.pop(0)
            try:
                self.responses.append({"url": resp.url, "status": resp.status, "body": resp.json()})
            except Exception:
                pass

    def json_matching(self, pattern: str) -> list[Any]:
        """Bodies of JSON GET responses whose URL matches. Call while the browser is open."""
        self._drain()
        rx = re.compile(pattern)
        return [r["body"] for r in self.responses if rx.search(r["url"]) and r["status"] == 200]

    def __exit__(self, *exc) -> None:
        try:
            if self.browser:
                self.browser.close()
        finally:
            if self._pw:
                self._pw.stop()


def interactive() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()
